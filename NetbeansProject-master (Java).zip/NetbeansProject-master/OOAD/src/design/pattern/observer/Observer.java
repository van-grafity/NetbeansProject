/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package design.pattern.observer;

/**
 *
 * @author User
 */
public interface Observer {
    public void update(int RPL, int OOAD, int ALPRO);
}
