package day07;

public class Mobil {
	private String warna;
	private String merk;
	private String nama_pemilik;
	private String plat_no;
	private int tahun;
	
	public String getWarna() {
		return warna;
	}

	public void setWarna(String warna) {
		this.warna = warna;
	}

	public String getMerk() {
		return merk;
	}

	public void setMerk(String merk) {
		this.merk = merk;
	}

	public String getNama_pemilik() {
		return nama_pemilik;
	}

	public void setNama_pemilik(String nama_pemilik) {
		this.nama_pemilik = nama_pemilik;
	}

	public String getPlat_no() {
		return plat_no;
	}

	public void setPlat_no(String plat_no) {
		this.plat_no = plat_no;
	}

	public int getTahun() {
		return tahun;
	}

	public void setTahun(int tahun) {
		this.tahun = tahun;
	}

	
}
