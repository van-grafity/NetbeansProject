/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.day09;

/**
 *
 * @author CHAR0
 */
public class Inheritance {
    public static void main(String[] args) {
        Cat c = new Cat();
        c.nama = "Pussy";
        c.jenis = "Kucing";
        c.say();
    }
}
